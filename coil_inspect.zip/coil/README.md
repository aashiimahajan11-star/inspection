# coil_inspect: pass/fail inspection for coated coils

Learns what a **good** coil looks like from good images only (no labelling),
finds the **tip / wire / band** areas by colour, and reports anything unusual
and where it is.

Three checks run on every image:

| Check | Needs training? | Catches |
|---|---|---|
| **Regions** (colour) | No | Finds tip (black), band (blue coating), wire (metal in gaps), bare metal (gold colour). Tip missing → FAIL. Bare metal on the coil → FAIL. |
| **Geometry** | No | Finds every turn, measures spacing. Stretched / opened coil, missing or squashed turn → FAIL. |
| **Anomaly model** (PatchCore) | Good parts only | Anything that doesn't look like a good part: cracks, chips, debris, fibres, odd damage you never thought of. Says which region it's in. |

Result per image: **PASS**, **REVIEW** (borderline, a person should look) or **FAIL**, with a list of findings.

## Install (on your PC)

```bash
pip install -r requirements.txt
```
An NVIDIA GPU makes it faster but a CPU works. The first `train` downloads the
pretrained backbone (~270 MB) once, so that PC needs internet the first time.

## Use

**1. Check the region finder on a few images first**
```bash
python -m coil_inspect regions my_images/ --out region_maps
```
Open `region_maps/`. Colours: blue = band, red = wire, cyan = tip, yellow = bare metal.
If an area is wrong (e.g. different lighting), adjust the numbers in
`coil_inspect/regions.py` → `RegionConfig`.

**2. Rule checks only (no training)**
```bash
python -m coil_inspect inspect my_images/ --out results
```

**3. Train the anomaly model on GOOD parts only**
```bash
python -m coil_inspect train good_parts/ --model coil_model.pt
```
* Put **only good parts** in that folder; one bad part teaches it that damage is normal.
* Use **original camera images**. Augmented copies (Blur/Noise versions) are detected
  automatically and grouped with their original so they never leak into the threshold set,
  but only originals are learned from.
* Aim for **100+ different good parts** with your normal variation. 20% are kept aside
  automatically to set the threshold.

**4. Inspect with everything**
```bash
python -m coil_inspect inspect new_images/ --model coil_model.pt --out results
```
Output in `results/`:
* `<image>_result.jpg`: left = image with heatmap and numbered boxes, top bar = decision;
  right = region map.
* `report.csv` / `report.json`: decision, anomaly score (1.0 = threshold), turn count,
  every finding with region, message and box.

## Tuning

* `--size 512` (default): raise to 768–1024 to catch finer cracks (slower).
* Too many REVIEW/FAIL on good parts → more good training images, consistent lighting,
  or widen `review_band` in `pipeline.py`.
* Geometry limits (`max_pitch_ratio`, `max_gap_ratio`) in `geometry.py`.
* Before using for real decisions: test on a fixed set of **known good and known bad parts**
  and set thresholds so no bad part passes.

## Important

* Lock camera exposure, white balance, zoom and lighting. The anomaly model flags *any*
  difference, including a lighting change.
* Don't train on heavily noised augmentations; they don't match your real camera.
* This is a starting tool, not validated software. For medical-device production it
  needs validation under your quality system.
