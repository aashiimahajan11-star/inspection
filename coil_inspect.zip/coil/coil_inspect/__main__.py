"""Command line:

  python -m coil_inspect regions  <images_dir> [--out region_maps]
  python -m coil_inspect train    <good_images_dir> [--model coil_model.pt]
  python -m coil_inspect inspect  <images_dir> [--model coil_model.pt] [--out results]
"""
import argparse

from .pipeline import inspect_folder, save_region_maps, train


def main():
    ap = argparse.ArgumentParser(prog="coil_inspect", description="Coil pass/fail inspection")
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("regions", help="save colour maps of tip/wire/band to check the region finder")
    r.add_argument("images")
    r.add_argument("--out", default="region_maps")

    t = sub.add_parser("train", help="learn 'normal' from a folder of GOOD parts only")
    t.add_argument("good_images")
    t.add_argument("--model", default="coil_model.pt")
    t.add_argument("--size", type=int, default=512, help="image size for the model (bigger = finer detail, slower)")
    t.add_argument("--memory", type=int, default=30000, help="number of 'good' patches to remember")
    t.add_argument("--calib-frac", type=float, default=0.2, help="share of good parts kept aside to set the threshold")
    t.add_argument("--no-pretrained", action="store_true", help=argparse.SUPPRESS)  # offline testing only

    i = sub.add_parser("inspect", help="inspect images and write a pass/fail report")
    i.add_argument("images")
    i.add_argument("--model", default=None, help="trained model; without it only rule checks run")
    i.add_argument("--out", default="results")

    a = ap.parse_args()
    if a.cmd == "regions":
        save_region_maps(a.images, a.out)
    elif a.cmd == "train":
        train(a.good_images, a.model, image_size=a.size, memory_size=a.memory,
              calib_frac=a.calib_frac, pretrained=not a.no_pretrained)
    else:
        inspect_folder(a.images, a.out, a.model)


if __name__ == "__main__":
    main()
