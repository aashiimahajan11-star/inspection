"""Colour-based region map: works out which pixels are tip, band (blue coating),
wire (metal seen in the gaps) and bare metal, with no training and no labels.

Thresholds live in RegionConfig. Run `python -m coil_inspect regions <folder>`
to save colour maps and check them before trusting anything else.
"""
from dataclasses import dataclass

import cv2
import numpy as np

# Region ids used everywhere in the tool
BACKGROUND, BAND, WIRE, TIP, BARE_METAL = 0, 1, 2, 3, 4
REGION_NAMES = {
    BACKGROUND: "background",
    BAND: "band",          # blue coating on each turn
    WIRE: "wire",          # metal visible between turns
    TIP: "tip",            # black end section
    BARE_METAL: "bare_metal",  # gold/copper colour where coating should be
}
REGION_COLOURS_BGR = {
    BACKGROUND: (40, 40, 40),
    BAND: (255, 120, 0),
    WIRE: (0, 0, 230),
    TIP: (230, 230, 0),
    BARE_METAL: (0, 200, 255),
}


@dataclass
class RegionConfig:
    # Background: light grey, almost no colour
    bg_max_sat: int = 45
    bg_min_val: int = 150
    # Blue coating (OpenCV hue is 0-179)
    band_hue: tuple = (95, 135)
    band_min_sat: int = 45
    band_min_val: int = 60
    # Black tip sleeve
    tip_max_val: int = 75
    tip_max_sat: int = 110
    # A column counts as "tip" when this share of the coil height is dark
    tip_col_dark_frac: float = 0.55
    # Gold / copper coloured metal (exposed where coating is missing)
    bare_hue: tuple = (5, 35)
    bare_min_sat: int = 70
    bare_min_val: int = 70
    # Clean-up
    median_ksize: int = 5          # removes salt-and-pepper specks
    min_object_area: int = 2000    # pixels


def _largest_components(mask, min_area):
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    keep = np.zeros_like(mask, dtype=bool)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            keep |= lab == i
    return keep


def region_map(bgr, cfg: RegionConfig = RegionConfig()):
    """Return (regions HxW uint8, info dict)."""
    img = cv2.medianBlur(bgr, cfg.median_ksize) if cfg.median_ksize > 1 else bgr
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]

    background = (s <= cfg.bg_max_sat) & (v >= cfg.bg_min_val)
    obj = ~background
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    obj = cv2.morphologyEx(obj.astype(np.uint8), cv2.MORPH_OPEN, k)
    obj = cv2.morphologyEx(obj, cv2.MORPH_CLOSE, k)
    obj = _largest_components(obj > 0, cfg.min_object_area)

    band = obj & (h >= cfg.band_hue[0]) & (h <= cfg.band_hue[1]) & \
        (s >= cfg.band_min_sat) & (v >= cfg.band_min_val)
    dark = obj & (v <= cfg.tip_max_val) & (s <= cfg.tip_max_sat)
    bare = obj & (h >= cfg.bare_hue[0]) & (h <= cfg.bare_hue[1]) & \
        (s >= cfg.bare_min_sat) & (v >= cfg.bare_min_val)

    # Tip zone: columns at one end of the part that are mostly dark
    cols = np.where(obj.any(axis=0))[0]
    tip_zone = np.zeros(bgr.shape[1], dtype=bool)
    tip_side = None
    if len(cols):
        height = obj.sum(axis=0).astype(float)
        dark_frac = np.divide(dark.sum(axis=0), height, out=np.zeros_like(height), where=height > 0)
        is_dark = dark_frac >= cfg.tip_col_dark_frac
        # grow from each end of the part; keep the longer run
        runs = {}
        for side, order in (("right", cols[::-1]), ("left", cols)):
            run = []
            for c in order:
                if is_dark[c]:
                    run.append(c)
                elif run:
                    break
                elif len(run) == 0 and abs(c - order[0]) > 20:
                    break  # dark run must start near the end
            runs[side] = run
        tip_side = max(runs, key=lambda k_: len(runs[k_]))
        if len(runs[tip_side]) >= 10:
            tip_zone[runs[tip_side]] = True
        else:
            tip_side = None

    regions = np.full(bgr.shape[:2], BACKGROUND, np.uint8)
    regions[obj] = WIRE                     # default inside the part: metal / gaps
    regions[band] = BAND
    regions[bare & ~tip_zone[None, :]] = BARE_METAL
    regions[obj & tip_zone[None, :]] = TIP

    coil_cols = cols[~tip_zone[cols]] if len(cols) else cols
    info = {
        "object_mask": obj,
        "tip_side": tip_side,
        "tip_cols": (int(np.where(tip_zone)[0].min()), int(np.where(tip_zone)[0].max())) if tip_zone.any() else None,
        "coil_cols": (int(coil_cols.min()), int(coil_cols.max())) if len(coil_cols) else None,
        "area": {REGION_NAMES[r]: int((regions == r).sum()) for r in REGION_NAMES},
    }
    return regions, info


def colourise(regions):
    out = np.zeros(regions.shape + (3,), np.uint8)
    for r, c in REGION_COLOURS_BGR.items():
        out[regions == r] = c
    return out
