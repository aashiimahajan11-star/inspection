"""Rule check for coil geometry: finds the gaps between turns and flags a coil
that is stretched, opened up or unevenly wound. Needs no training."""
from dataclasses import dataclass

import cv2
import numpy as np
from scipy.signal import find_peaks

from .regions import BAND


@dataclass
class GeometryConfig:
    centre_rows_frac: float = 0.4     # use the middle 40% of the coil height
    gap_max_band_frac: float = 0.5    # a column is "gap" if < 50% of it is blue
    min_gap_width: int = 2            # px, ignore single-pixel noise
    edge_margin: int = 6              # ignore columns this close to the coil ends
    max_gap_ratio: float = 2.5        # flag a gap wider than 2.5x the median gap
    max_pitch_ratio: float = 1.6      # flag turn spacing > 1.6x the median spacing
    min_pitch_ratio: float = 0.55     # flag turn spacing < 0.55x median (squashed/overlapping)
    valley_prominence: float = 8.0    # how dark a turn boundary must be (grey levels)
    min_turns: int = 5                # fewer turns than this -> cannot judge


def _runs(bool_arr):
    runs, start = [], None
    for i, b in enumerate(bool_arr):
        if b and start is None:
            start = i
        elif not b and start is not None:
            runs.append((start, i - 1))
            start = None
    if start is not None:
        runs.append((start, len(bool_arr) - 1))
    return runs


def _pitch_autocorr(profile, lo=10, hi=200):
    x = profile - profile.mean()
    ac = np.correlate(x, x, mode="full")[len(x) - 1:]
    hi = min(hi, len(ac) - 1)
    if hi <= lo:
        return None
    peaks, _ = find_peaks(ac[lo:hi])
    return float(peaks[np.argmax(ac[lo:hi][peaks])] + lo) if len(peaks) else None


def check_geometry(regions, info, cfg: GeometryConfig = GeometryConfig(), bgr=None):
    """Returns dict with gaps, pitches and a list of findings (empty = OK)."""
    result = {"gaps": [], "pitch_median": None, "gap_median": None, "findings": [], "checked": False}
    if info["coil_cols"] is None:
        result["findings"].append({"type": "no_coil_found", "msg": "Could not find the coil in the image"})
        return result
    c0, c1 = info["coil_cols"]
    c0, c1 = c0 + cfg.edge_margin, c1 - cfg.edge_margin
    if c1 - c0 < 50:
        return result

    obj = info["object_mask"]
    rows = np.where(obj[:, c0:c1].any(axis=1))[0]
    top, bot = rows.min(), rows.max()
    mid, half = (top + bot) / 2, (bot - top) * cfg.centre_rows_frac / 2
    r0, r1 = int(mid - half), int(mid + half) + 1

    strip = regions[r0:r1, c0:c1]
    band_frac = (strip == BAND).mean(axis=0)
    gaps = [(a + c0, b + c0) for a, b in _runs(band_frac < cfg.gap_max_band_frac)
            if b - a + 1 >= cfg.min_gap_width]
    result["gaps"] = gaps
    # Turn boundaries = dark valleys in the brightness profile along the coil
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY).astype(float) if bgr is not None \
        else (strip == BAND).astype(float) * 255
    profile = gray[r0:r1, c0:c1].mean(axis=0) if bgr is not None else gray.mean(axis=0)
    profile = np.convolve(profile, np.ones(3) / 3, mode="same")
    pitch_guess = _pitch_autocorr(profile)
    if pitch_guess is None:
        result["findings"].append({"type": "no_turns", "x": None,
                                   "msg": "Could not find a repeating turn pattern"})
        return result
    valleys, _ = find_peaks(-profile, prominence=cfg.valley_prominence,
                            distance=max(3, int(0.6 * pitch_guess)))
    boundaries = valleys + c0
    result["boundaries"] = boundaries.tolist()
    if len(boundaries) < cfg.min_turns:
        result["findings"].append({"type": "too_few_turns", "x": None,
                                   "msg": f"Only {len(boundaries)} turn boundaries found"})
        return result

    pitches = np.diff(boundaries).astype(float)
    pmed = float(np.median(pitches))
    widths = np.array([b - a + 1 for a, b in gaps], float)
    gmed = float(np.median(widths)) if len(widths) else 0.0
    result.update(checked=True, gap_median=gmed, pitch_median=pmed, rows=(r0, r1),
                  turns=len(boundaries) + 1)

    for (a, b), w in zip(gaps, widths):
        if w > cfg.max_gap_ratio * max(gmed, 2) and w > 0.35 * pmed:
            result["findings"].append({
                "type": "wide_gap", "x": (int(a), int(b)),
                "msg": f"Gap {w:.0f}px wide at x={a}-{b} (turn pitch ~{pmed:.0f}px): coil stretched or opened"})
    for i, p in enumerate(pitches):
        a, b = int(boundaries[i]), int(boundaries[i + 1])
        if p > cfg.max_pitch_ratio * pmed:
            result["findings"].append({
                "type": "uneven_spacing", "x": (a, b),
                "msg": f"Turn spacing {p:.0f}px at x={a}-{b} (normal ~{pmed:.0f}px): stretched, missing or displaced turn"})
        elif p < cfg.min_pitch_ratio * pmed:
            result["findings"].append({
                "type": "squashed_turn", "x": (a, b),
                "msg": f"Turn spacing {p:.0f}px at x={a}-{b} (normal ~{pmed:.0f}px): squashed, overlapping or cracked turn"})
    return result
