"""Glue: dataset handling, training, and per-image inspection with a written report."""
import json
import os
from dataclasses import asdict

import cv2
import numpy as np

from .geometry import GeometryConfig, check_geometry
from .regions import (BACKGROUND, BARE_METAL, REGION_NAMES, TIP, RegionConfig,
                      colourise, region_map)

IMG_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff")


# ---------------------------------------------------------------- dataset ---
def list_images(folder):
    out = []
    for root, _, files in os.walk(folder):
        out += [os.path.join(root, f) for f in files if f.lower().endswith(IMG_EXT)]
    return sorted(out)


def _ahash(bgr):
    g = cv2.cvtColor(cv2.medianBlur(bgr, 5), cv2.COLOR_BGR2GRAY)
    g = cv2.resize(g, (16, 16), interpolation=cv2.INTER_AREA).astype(float)
    return (g > g.mean()).flatten()


def group_near_duplicates(paths, max_bits=6):
    """Groups an image with its augmented copies (blur/noise/zoom versions), so a
    copy of a part never ends up in both the training and the calibration set."""
    hashes = [_ahash(cv2.imread(p)) for p in paths]
    groups, assigned = [], [-1] * len(paths)
    for i in range(len(paths)):
        if assigned[i] >= 0:
            continue
        assigned[i] = len(groups)
        g = [i]
        for j in range(i + 1, len(paths)):
            if assigned[j] < 0 and np.count_nonzero(hashes[i] != hashes[j]) <= max_bits:
                assigned[j] = assigned[i]
                g.append(j)
        groups.append([paths[k] for k in g])
    return groups


# --------------------------------------------------------------- training ---
def train(good_dir, model_path, image_size=512, memory_size=30000, calib_frac=0.2,
          pretrained=True, seed=0, log=print):
    from .anomaly import PatchCore
    import torch

    paths = list_images(good_dir)
    if not paths:
        raise SystemExit(f"No images found in {good_dir}")
    groups = group_near_duplicates(paths)
    log(f"{len(paths)} images -> {len(groups)} unique parts (augmented copies grouped together)")
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(groups))
    n_cal = int(round(len(groups) * calib_frac))
    if len(groups) - n_cal < 1 or n_cal < 3:
        log("WARNING: too few unique good parts for a separate calibration set. "
            "Thresholds will be estimated from the training images and will be too strict "
            "-> expect extra REVIEW results. Collect more good parts (100+ recommended).")
        n_cal = 0
    cal_groups = [groups[i] for i in order[:n_cal]]
    fit_groups = [groups[i] for i in order[n_cal:]]
    # Train on originals only: one image per part (augmented copies add no information
    # about what a good part looks like and would bias the memory bank).
    fit_paths = [sorted(g, key=len)[0] for g in fit_groups]
    cal_paths = [p for g in cal_groups for p in g]

    model = PatchCore(image_size=image_size, memory_size=memory_size, pretrained=pretrained, seed=seed)
    log(f"Learning 'good' from {len(fit_paths)} images on {model.device} ...")
    model.fit([cv2.imread(p) for p in fit_paths], log=log)

    score_paths = cal_paths if cal_paths else fit_paths
    scores = []
    for p in score_paths:
        s, _ = model.score(cv2.imread(p))
        scores.append(s)
    scores = np.array(scores)
    margin = 1.0 if cal_paths else 1.5
    threshold = float(scores.max() * margin)
    log(f"Good-part scores on {'calibration' if cal_paths else 'training'} images: "
        f"min {scores.min():.3f} / median {np.median(scores):.3f} / max {scores.max():.3f}")
    log(f"Anomaly threshold set to {threshold:.3f}")

    torch.save({
        "patchcore": model.state_dict(),
        "threshold": threshold,
        "good_scores": scores.tolist(),
        "pretrained": pretrained,
        "train_images": fit_paths,
        "calib_images": cal_paths,
    }, model_path)
    log(f"Saved {model_path}")


# ------------------------------------------------------------- inspection ---
DECISION_COLOURS = {"PASS": (60, 170, 60), "REVIEW": (0, 165, 255), "FAIL": (40, 40, 220)}


class Inspector:
    def __init__(self, model_path=None, review_band=(0.9, 1.15),
                 region_cfg=RegionConfig(), geom_cfg=GeometryConfig(),
                 min_bare_metal_px=150, min_blob_px=60):
        self.region_cfg, self.geom_cfg = region_cfg, geom_cfg
        self.review_band = review_band
        self.min_bare_metal_px = min_bare_metal_px
        self.min_blob_px = min_blob_px
        self.model, self.threshold = None, None
        if model_path:
            import torch
            from .anomaly import PatchCore
            ck = torch.load(model_path, map_location="cpu", weights_only=False)
            self.model = PatchCore(pretrained=ck.get("pretrained", True))
            self.model.load_state_dict(ck["patchcore"])
            self.threshold = ck["threshold"]

    # -- helpers
    @staticmethod
    def _dominant_region(regions, mask):
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
        under = regions[cv2.dilate(mask.astype(np.uint8), k) > 0]
        part = under[under != BACKGROUND]
        if part.size < 0.15 * under.size:
            return "outside_coil"
        vals, counts = np.unique(part, return_counts=True)
        return REGION_NAMES[int(vals[np.argmax(counts)])]

    @staticmethod
    def _hint(region, bare_px):
        if bare_px > 30:
            return "possible coating damage: bare metal visible"
        return {
            "tip": "unusual appearance at the tip / tip joint",
            "wire": "unusual in the wire / gap area (crack, debris, displaced wire?)",
            "band": "unusual on the coating (chip, crack, dent, contamination?)",
            "bare_metal": "possible coating damage: bare metal visible",
            "outside_coil": "material outside the coil outline (loose flap, fibre, debris?)",
        }.get(region, "unusual area")

    # -- main
    def inspect(self, bgr):
        regions, info = region_map(bgr, self.region_cfg)
        geom = check_geometry(regions, info, self.geom_cfg, bgr=bgr)
        findings = []

        # rule: tip present
        if info["tip_cols"] is None:
            findings.append({"source": "rule", "region": "tip", "severity": "fail",
                             "msg": "Tip not found at either end of the part", "bbox": None})

        # rule: geometry
        for g in geom["findings"]:
            x = g.get("x")
            bbox = None
            if x and geom.get("rows"):
                r0, r1 = geom["rows"]
                bbox = (int(x[0]), int(r0), int(x[1] - x[0] + 1), int(r1 - r0))
            findings.append({"source": "geometry", "region": "wire", "severity": "fail",
                             "msg": g["msg"], "bbox": bbox})

        # rule: bare metal on the coil
        bare = (regions == BARE_METAL).astype(np.uint8)
        n, lab, stats, _ = cv2.connectedComponentsWithStats(
            cv2.morphologyEx(bare, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)), 8)
        for i in range(1, n):
            if stats[i, cv2.CC_STAT_AREA] >= self.min_bare_metal_px:
                x, y, w, h = stats[i, :4]
                findings.append({"source": "colour", "region": "band", "severity": "fail",
                                 "msg": f"Bare metal colour on coil ({stats[i, cv2.CC_STAT_AREA]} px): coating missing or damaged",
                                 "bbox": (int(x), int(y), int(w), int(h))})

        # learned: anomaly detection
        score, heat = None, None
        if self.model is not None:
            score, heat = self.model.score(bgr)
            lo = self.review_band[0] * self.threshold
            hot = (heat >= lo).astype(np.uint8)
            n, lab, stats, _ = cv2.connectedComponentsWithStats(hot, 8)
            for i in range(1, n):
                if stats[i, cv2.CC_STAT_AREA] < self.min_blob_px:
                    continue
                m = lab == i
                peak = float(heat[m].max())
                region = self._dominant_region(regions, m)
                bare_px = int(((regions == BARE_METAL) & m).sum())
                sev = "fail" if peak >= self.review_band[1] * self.threshold else \
                    "review" if peak >= self.threshold * self.review_band[0] else "info"
                x, y, w, h = stats[i, :4]
                findings.append({"source": "anomaly", "region": region, "severity": sev,
                                 "score": round(peak / self.threshold, 2),
                                 "msg": self._hint(region, bare_px),
                                 "bbox": (int(x), int(y), int(w), int(h))})

        sevs = {f["severity"] for f in findings}
        decision = "FAIL" if "fail" in sevs else "REVIEW" if "review" in sevs else "PASS"
        return {
            "decision": decision,
            "anomaly_score": None if score is None else round(score / self.threshold, 3),
            "turns": geom.get("turns"),
            "turn_pitch_px": geom.get("pitch_median"),
            "tip_found": info["tip_cols"] is not None,
            "region_area_px": info["area"],
            "findings": findings,
        }, regions, heat

    # -- drawing
    def draw(self, bgr, result, regions, heat):
        out = bgr.copy()
        if heat is not None and self.threshold:
            norm = np.clip(heat / (self.threshold * 1.5), 0, 1)
            cm = cv2.applyColorMap((norm * 255).astype(np.uint8), cv2.COLORMAP_JET)
            alpha = (np.clip((norm - 0.5) * 2, 0, 1) * 0.6)[..., None]
            out = (out * (1 - alpha) + cm * alpha).astype(np.uint8)
        sev_col = {"fail": (40, 40, 220), "review": (0, 165, 255), "info": (180, 180, 180)}
        for i, f in enumerate(result["findings"], 1):
            if not f["bbox"]:
                continue
            x, y, w, h = f["bbox"]
            col = sev_col[f["severity"]]
            cv2.rectangle(out, (x, y), (x + w, y + h), col, 2)
            cv2.putText(out, f"{i}:{f['region']}", (x, max(12, y - 4)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, col, 1, cv2.LINE_AA)
        d = result["decision"]
        cv2.rectangle(out, (0, 0), (out.shape[1], 34), DECISION_COLOURS[d], -1)
        s = "" if result["anomaly_score"] is None else f"  anomaly {result['anomaly_score']:.2f}x threshold"
        cv2.putText(out, f"{d}{s}", (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2, cv2.LINE_AA)
        regmap = cv2.addWeighted(bgr, 0.35, colourise(regions), 0.65, 0)
        return np.hstack([out, regmap])


def inspect_folder(images_dir, out_dir, model_path=None, log=print):
    os.makedirs(out_dir, exist_ok=True)
    insp = Inspector(model_path)
    if model_path is None:
        log("No model given: running rule checks only (tip, geometry, bare metal).")
    rows, report = [], {}
    for p in list_images(images_dir):
        bgr = cv2.imread(p)
        if bgr is None:
            log(f"skip unreadable {p}")
            continue
        res, regions, heat = insp.inspect(bgr)
        name = os.path.splitext(os.path.basename(p))[0]
        cv2.imwrite(os.path.join(out_dir, name + "_result.jpg"), insp.draw(bgr, res, regions, heat))
        report[p] = res
        summary = "; ".join(f"[{i}] {f['region']}: {f['msg']}" for i, f in enumerate(res["findings"], 1)
                            if f["severity"] != "info")
        rows.append((os.path.basename(p), res["decision"], res["anomaly_score"], res["turns"], summary))
        log(f"{res['decision']:6s} {os.path.basename(p)}  {summary}")
    with open(os.path.join(out_dir, "report.json"), "w") as fh:
        json.dump(report, fh, indent=2)
    import csv
    with open(os.path.join(out_dir, "report.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["image", "decision", "anomaly_score_x_threshold", "turns", "findings"])
        w.writerows(rows)
    counts = {d: sum(r[1] == d for r in rows) for d in ("PASS", "REVIEW", "FAIL")}
    log(f"\nDone: {counts}. Results in {out_dir}")


def save_region_maps(images_dir, out_dir, log=print):
    os.makedirs(out_dir, exist_ok=True)
    for p in list_images(images_dir):
        bgr = cv2.imread(p)
        regions, info = region_map(bgr)
        name = os.path.splitext(os.path.basename(p))[0]
        cv2.imwrite(os.path.join(out_dir, name + "_regions.jpg"),
                    np.hstack([bgr, cv2.addWeighted(bgr, 0.35, colourise(regions), 0.65, 0)]))
        log(f"{os.path.basename(p)}: tip={info['tip_side']}  areas={info['area']}")
    log("Colours: blue=band  red=wire  cyan=tip  yellow=bare metal  dark=background")
