"""PatchCore-style anomaly detection.

Learns what *good* coils look like from good images only (no labels). At
inspection time every small patch of the image is compared with the nearest
"good" patch it has seen; patches with no close match get a high score.
"""
import math

import cv2
import numpy as np
import torch
import torch.nn.functional as F
import torchvision

IMAGENET_MEAN = np.array([0.485, 0.456, 0.406], np.float32)
IMAGENET_STD = np.array([0.229, 0.224, 0.225], np.float32)


class FeatureExtractor(torch.nn.Module):
    """Mid-level features (layer2 + layer3) of a pretrained WideResNet-50."""

    def __init__(self, pretrained=True):
        super().__init__()
        weights = torchvision.models.Wide_ResNet50_2_Weights.IMAGENET1K_V1 if pretrained else None
        net = torchvision.models.wide_resnet50_2(weights=weights)
        self.stem = torch.nn.Sequential(net.conv1, net.bn1, net.relu, net.maxpool, net.layer1)
        self.layer2, self.layer3 = net.layer2, net.layer3
        self.eval()

    @torch.no_grad()
    def forward(self, x):
        f2 = self.layer2(self.stem(x))
        f3 = self.layer3(f2)
        # local neighbourhood averaging makes features robust to tiny shifts
        f2 = F.avg_pool2d(f2, 3, 1, 1)
        f3 = F.avg_pool2d(f3, 3, 1, 1)
        f3 = F.interpolate(f3, size=f2.shape[-2:], mode="bilinear", align_corners=False)
        return torch.cat([f2, f3], 1)  # B x 1536 x H/8 x W/8


def preprocess(bgr, size):
    """Resize keeping aspect ratio (long side = size), pad to multiple of 32."""
    h, w = bgr.shape[:2]
    scale = size / max(h, w)
    nh, nw = int(round(h * scale)), int(round(w * scale))
    img = cv2.resize(bgr, (nw, nh), interpolation=cv2.INTER_AREA)
    ph, pw = math.ceil(nh / 32) * 32, math.ceil(nw / 32) * 32
    img = cv2.copyMakeBorder(img, 0, ph - nh, 0, pw - nw, cv2.BORDER_REPLICATE)
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    rgb = (rgb - IMAGENET_MEAN) / IMAGENET_STD
    t = torch.from_numpy(rgb.transpose(2, 0, 1))[None]
    return t, (nh, nw)


class PatchCore:
    def __init__(self, image_size=512, memory_size=30000, pretrained=True, device=None, seed=0):
        self.image_size = image_size
        self.memory_size = memory_size
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        torch.manual_seed(seed)  # only matters for the offline --no-pretrained test mode
        self.extractor = FeatureExtractor(pretrained).to(self.device)
        self.memory = None
        self.rng = np.random.default_rng(seed)

    def _features(self, bgr):
        t, valid = preprocess(bgr, self.image_size)
        f = self.extractor(t.to(self.device))[0]       # C x h x w
        return f, valid, t.shape[-2:]

    def fit(self, images, log=print):
        per_image = max(1, int(self.memory_size * 3 / max(len(images), 1)))
        pool = []
        for i, bgr in enumerate(images):
            f, _, _ = self._features(bgr)
            p = f.flatten(1).T                          # N x C
            idx = self.rng.choice(len(p), size=min(per_image, len(p)), replace=False)
            pool.append(p[torch.as_tensor(idx, device=p.device)].cpu())
            log(f"  features {i + 1}/{len(images)}")
        pool = torch.cat(pool)
        self.memory = self._coreset(pool, self.memory_size)
        log(f"  memory bank: {len(self.memory)} patches")

    def _coreset(self, pool, n):
        """Greedy coreset: pick patches that cover the variety of 'good' looks."""
        if len(pool) <= n:
            return pool
        dev = self.device
        proj = torch.randn(pool.shape[1], 128, generator=torch.Generator().manual_seed(0)) / 128 ** 0.5
        z = (pool @ proj).to(dev)
        sel = [int(self.rng.integers(len(z)))]
        mind = torch.cdist(z, z[sel]).squeeze(1)
        for _ in range(n - 1):
            j = int(torch.argmax(mind))
            sel.append(j)
            mind = torch.minimum(mind, torch.cdist(z, z[j:j + 1]).squeeze(1))
        return pool[torch.as_tensor(sel)]

    @torch.no_grad()
    def score(self, bgr, chunk=4096):
        """Returns (image_score, heatmap HxW float32 aligned with the input image)."""
        f, (nh, nw), (ph, pw) = self._features(bgr)
        c, h, w = f.shape
        q = f.flatten(1).T
        mem = self.memory.to(self.device)
        d = torch.cat([torch.cdist(q[i:i + chunk], mem).min(1).values for i in range(0, len(q), chunk)])
        amap = d.reshape(1, 1, h, w)
        amap = F.interpolate(amap, size=(ph, pw), mode="bilinear", align_corners=False)[0, 0]
        amap = amap[:nh, :nw].cpu().numpy()
        amap = cv2.resize(amap, (bgr.shape[1], bgr.shape[0]), interpolation=cv2.INTER_LINEAR)
        amap = cv2.GaussianBlur(amap, (0, 0), sigmaX=4)
        return float(amap.max()), amap.astype(np.float32)

    def state_dict(self):
        return {"image_size": self.image_size, "memory_size": self.memory_size, "memory": self.memory}

    def load_state_dict(self, sd):
        self.image_size, self.memory_size, self.memory = sd["image_size"], sd["memory_size"], sd["memory"]
